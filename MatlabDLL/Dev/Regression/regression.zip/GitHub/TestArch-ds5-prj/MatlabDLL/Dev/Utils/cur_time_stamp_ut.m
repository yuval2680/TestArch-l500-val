function out = cur_time_stamp_ut()
out = sprintf('%.3f', posixtime(datetime));
end