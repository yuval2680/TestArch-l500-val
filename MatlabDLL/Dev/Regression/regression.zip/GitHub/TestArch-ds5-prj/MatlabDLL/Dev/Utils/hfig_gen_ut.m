function h = hfig_gen_ut(func_name)
%HFIG_GEN Summary of this function goes here
%   Detailed explanation goes here
h = sum(func_name);
end

