function save_figure(fig_name, res_dir, res_name)
% Function description: This function manages figures saving in the flow.
% The figure is saved as both PNG and FIG file.
% Function Matlab name: 
% save_figure(fig_name, res_dir, res_name)
% Input:
% fig_name: String. Name of the figure; this is the name of the Matlab
% function that have generated the figure, e.g. 'uniformity_sa'.
% res_dir: String. Results directory ended by '\'
% res_name: String. Results file name without the extention.
% Output: NA
hf = figure(hfig_gen_ut(fig_name));
drawnow;
print([res_dir, res_name, '.png'],'-dpng');
savefig(hf, [res_dir, res_name, '.fig'])

end

